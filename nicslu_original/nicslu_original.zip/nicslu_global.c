/*global parameters*/

#include "nicslu.h"

size_t g_sd = sizeof(real__t);
size_t g_si = sizeof(int__t);
size_t g_sp = sizeof(real__t) + sizeof(int__t);
size_t g_sis1 = sizeof(int__t) - 1;
size_t g_sps1 = sizeof(real__t) + sizeof(int__t) - 1;
